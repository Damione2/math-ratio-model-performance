#!/usr/bin/env python3
# scripts/plot_ablation_results.py
"""
Aggregate ablation experiment results and produce summary CSV/JSON, plots, regression,
and a small Markdown report.

Run from project root:
    python scripts/plot_ablation_results.py
"""
from pathlib import Path
import json
import sys
import traceback
import warnings

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import linregress

sns.set(style="whitegrid")

ROOT = Path.cwd()
EXPERIMENTS_DIR = ROOT / "experiments"
PLOTS_DIR = EXPERIMENTS_DIR / "plots"
PLOTS_DIR.mkdir(parents=True, exist_ok=True)

SUMMARY_CSV = EXPERIMENTS_DIR / "ablation_summary.csv"
SUMMARY_JSON = EXPERIMENTS_DIR / "ablation_summary.json"
REGRESSION_JSON = PLOTS_DIR / "regression_bestf1_vs_mathratio.json"
REPORT_MD = PLOTS_DIR / "ablation_report.md"

# Expected filenames inside each experiment folder
SUMMARY_FILENAME = "training_summary.json"
LOG_FILENAME = "training_log.csv"

processed = []
warnings_list = []

def safe_load_json(path: Path):
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        warnings_list.append(f"Failed to load JSON {path}: {e}")
        return None

def safe_load_csv(path: Path):
    try:
        return pd.read_csv(path, encoding="utf-8")
    except Exception as e:
        warnings_list.append(f"Failed to load CSV {path}: {e}")
        return None

def infer_math_ratio_from_name(name: str):
    # Try to parse 'math_50' or 'math50' or 'math-50' or '50'
    lower = name.lower()
    for sep in ["math_", "math-", "math", "m_"]:
        if lower.startswith(sep):
            tail = lower[len(sep):]
            try:
                pct = int(''.join(ch for ch in tail if ch.isdigit()))
                return float(pct) / 100.0
            except Exception:
                continue
    # fallback: find any number in name
    import re
    m = re.search(r"(\d{1,3})", name)
    if m:
        try:
            pct = int(m.group(1))
            return float(pct) / 100.0
        except Exception:
            pass
    return None

# Discover experiment folders
exp_folders = [p for p in EXPERIMENTS_DIR.iterdir() if p.is_dir()]
if not exp_folders:
    print(f"No experiment subfolders found under {EXPERIMENTS_DIR}. Exiting.")
    sys.exit(1)

rows = []
for exp in sorted(exp_folders):
    try:
        summary_path = exp / SUMMARY_FILENAME
        log_path = exp / LOG_FILENAME

        if not summary_path.exists():
            warnings_list.append(f"Missing {SUMMARY_FILENAME} in {exp.name}; skipping.")
            continue
        if not log_path.exists():
            warnings_list.append(f"Missing {LOG_FILENAME} in {exp.name}; skipping.")
            continue

        summary = safe_load_json(summary_path)
        if summary is None:
            warnings_list.append(f"Could not parse {summary_path}; skipping.")
            continue

        log_df = safe_load_csv(log_path)
        if log_df is None or log_df.empty:
            warnings_list.append(f"Could not parse or empty {log_path}; skipping.")
            continue

        # Normalize column names
        log_df.columns = [c.strip() for c in log_df.columns]

        # Required columns: epoch,val_acc,val_f1,val_ece,code_acc,math_acc,real_acc,timestamp
        required_cols = ["epoch", "val_acc", "val_f1", "val_ece", "code_acc", "math_acc", "real_acc"]
        missing_cols = [c for c in required_cols if c not in log_df.columns]
        if missing_cols:
            warnings_list.append(f"Missing columns {missing_cols} in {log_path}; skipping.")
            continue

        best_epoch = summary.get("best_epoch", None)
        best_f1 = summary.get("best_f1", None)
        math_ratio = summary.get("math_ratio", None)

        # If best_epoch missing, try to infer from best_f1 in log
        if best_epoch is None:
            if best_f1 is not None:
                # find epoch with closest val_f1
                idx = (log_df["val_f1"] - float(best_f1)).abs().idxmin()
                best_epoch = int(log_df.loc[idx, "epoch"])
            else:
                # fallback to epoch with max val_f1
                idx = log_df["val_f1"].idxmax()
                best_epoch = int(log_df.loc[idx, "epoch"])
                best_f1 = float(log_df.loc[idx, "val_f1"])

        # Ensure numeric types
        try:
            best_epoch = int(best_epoch)
        except Exception:
            warnings_list.append(f"Invalid best_epoch in {summary_path}; skipping.")
            continue
        try:
            best_f1 = float(best_f1)
        except Exception:
            # try to read from log at best_epoch
            row_match = log_df[log_df["epoch"] == best_epoch]
            if not row_match.empty:
                best_f1 = float(row_match.iloc[0]["val_f1"])
            else:
                warnings_list.append(f"Invalid best_f1 in {summary_path} and not found in log; skipping.")
                continue

        # math_ratio fallback
        if math_ratio is None:
            inferred = infer_math_ratio_from_name(exp.name)
            math_ratio = inferred if inferred is not None else None

        # Get metrics at best_epoch from log
        row_match = log_df[log_df["epoch"] == best_epoch]
        if row_match.empty:
            # try nearest epoch
            idx = (log_df["epoch"] - best_epoch).abs().idxmin()
            row = log_df.loc[idx]
        else:
            row = row_match.iloc[0]

        math_acc_at_best = float(row.get("math_acc", np.nan))
        code_acc_at_best = float(row.get("code_acc", np.nan))
        real_acc_at_best = float(row.get("real_acc", np.nan))
        val_ece_at_best = float(row.get("val_ece", np.nan))
        n_epochs = int(len(log_df))

        rows.append({
            "experiment_name": exp.name,
            "math_ratio": float(math_ratio) if math_ratio is not None else None,
            "best_f1": float(best_f1),
            "best_epoch": int(best_epoch),
            "math_acc_at_best_epoch": math_acc_at_best,
            "code_acc_at_best_epoch": code_acc_at_best,
            "real_acc_at_best_epoch": real_acc_at_best,
            "val_ece_at_best_epoch": val_ece_at_best,
            "n_epochs": n_epochs,
            "log_path": str(log_path),
            "summary_path": str(summary_path)
        })

        # Keep per-experiment log for epoch plots
        processed.append({
            "name": exp.name,
            "math_ratio": float(math_ratio) if math_ratio is not None else None,
            "log_df": log_df.sort_values("epoch").reset_index(drop=True)
        })

    except Exception as e:
        warnings_list.append(f"Unhandled error processing {exp.name}: {e}")
        traceback.print_exc()

# Build DataFrame
if not rows:
    print("No valid experiment results found. Exiting.")
    for w in warnings_list:
        print("WARN:", w)
    sys.exit(1)

summary_df = pd.DataFrame(rows)
# Sort by math_ratio (None last)
summary_df["math_ratio_sort"] = summary_df["math_ratio"].apply(lambda x: x if x is not None else 2.0)
summary_df = summary_df.sort_values("math_ratio_sort").drop(columns=["math_ratio_sort"]).reset_index(drop=True)

# Save CSV and JSON summary
summary_df.to_csv(SUMMARY_CSV, index=False, encoding="utf-8")
with SUMMARY_JSON.open("w", encoding="utf-8") as f:
    json.dump(summary_df.to_dict(orient="records"), f, indent=2, ensure_ascii=False)

# Plot helpers
def save_fig(fig, path: Path):
    fig.set_size_inches(12, 8)
    fig.savefig(path, dpi=100, bbox_inches="tight")
    plt.close(fig)

# Convert math_ratio to numeric percentage for plotting
summary_df["math_pct"] = summary_df["math_ratio"].apply(lambda x: int(round(x * 100)) if x is not None else None)

# Plot A: math_ratio vs best_f1
try:
    fig, ax = plt.subplots()
    sns.scatterplot(data=summary_df, x="math_pct", y="best_f1", hue="experiment_name", s=120, ax=ax, legend=False)
    for _, r in summary_df.iterrows():
        if pd.notnull(r["math_pct"]):
            ax.text(r["math_pct"], r["best_f1"], f" {r['experiment_name']}", verticalalignment="center", fontsize=9)
    ax.set_xlabel("Math ratio (%)")
    ax.set_ylabel("Best Val F1")
    ax.set_title("Math ratio vs Best Val F1")
    save_fig(fig, PLOTS_DIR / "mathratio_vs_bestf1.png")
except Exception as e:
    warnings_list.append(f"Failed to create plot mathratio_vs_bestf1: {e}")

# Plot B: math_ratio vs math_acc_at_best_epoch
try:
    fig, ax = plt.subplots()
    sns.scatterplot(data=summary_df, x="math_pct", y="math_acc_at_best_epoch", hue="experiment_name", s=120, ax=ax, legend=False)
    ax.set_xlabel("Math ratio (%)")
    ax.set_ylabel("Math accuracy at best epoch")
    ax.set_title("Math ratio vs Math Accuracy (at best epoch)")
    save_fig(fig, PLOTS_DIR / "mathratio_vs_mathacc.png")
except Exception as e:
    warnings_list.append(f"Failed to create plot mathratio_vs_mathacc: {e}")

# Plot C: math_ratio vs code_acc_at_best_epoch
try:
    fig, ax = plt.subplots()
    sns.scatterplot(data=summary_df, x="math_pct", y="code_acc_at_best_epoch", hue="experiment_name", s=120, ax=ax, legend=False)
    ax.set_xlabel("Math ratio (%)")
    ax.set_ylabel("Code accuracy at best epoch")
    ax.set_title("Math ratio vs Code Accuracy (at best epoch)")
    save_fig(fig, PLOTS_DIR / "mathratio_vs_codeacc.png")
except Exception as e:
    warnings_list.append(f"Failed to create plot mathratio_vs_codeacc: {e}")

# Plot D: val_f1 over epochs (one line per experiment)
try:
    fig, ax = plt.subplots()
    for item in processed:
        df = item["log_df"]
        label = item["name"]
        x = df["epoch"]
        y = df["val_f1"]
        ax.plot(x, y, label=label, linewidth=1.5)
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Val F1")
    ax.set_title("Validation F1 over Epochs")
    ax.legend(loc="best", fontsize="small")
    save_fig(fig, PLOTS_DIR / "val_f1_epochs.png")
except Exception as e:
    warnings_list.append(f"Failed to create plot val_f1_epochs: {e}")

# Plot E: math_acc over epochs
try:
    fig, ax = plt.subplots()
    for item in processed:
        df = item["log_df"]
        label = item["name"]
        x = df["epoch"]
        y = df["math_acc"]
        ax.plot(x, y, label=label, linewidth=1.5)
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Math Accuracy")
    ax.set_title("Math Accuracy over Epochs")
    ax.legend(loc="best", fontsize="small")
    save_fig(fig, PLOTS_DIR / "math_acc_epochs.png")
except Exception as e:
    warnings_list.append(f"Failed to create plot math_acc_epochs: {e}")

# Regression: best_f1 ~ math_ratio (use numeric math_pct)
regression_result = {}
try:
    reg_df = summary_df.dropna(subset=["math_pct", "best_f1"])
    if len(reg_df) >= 2:
        x = reg_df["math_pct"].astype(float).values
        y = reg_df["best_f1"].astype(float).values
        res = linregress(x, y)
        regression_result = {
            "slope": res.slope,
            "intercept": res.intercept,
            "r_value": res.rvalue,
            "r_squared": res.rvalue ** 2,
            "p_value": res.pvalue,
            "stderr": res.stderr,
            "n": int(len(x))
        }
    else:
        regression_result = {"error": "Not enough points for regression", "n": int(len(reg_df))}
except Exception as e:
    regression_result = {"error": str(e)}

with open(REGRESSION_JSON, "w", encoding="utf-8") as f:
    json.dump(regression_result, f, indent=2, ensure_ascii=False)

# Markdown report
try:
    md_lines = []
    md_lines.append("# Ablation Summary Report\n")
    md_lines.append("## Summary table\n")
    # Convert summary_df to markdown table (select columns)
    md_table = summary_df[[
        "experiment_name", "math_ratio", "best_f1", "best_epoch",
        "math_acc_at_best_epoch", "code_acc_at_best_epoch", "real_acc_at_best_epoch",
        "val_ece_at_best_epoch", "n_epochs"
    ]].copy()
    # Format math_ratio as percentage string
    md_table["math_ratio"] = md_table["math_ratio"].apply(lambda x: f"{int(round(x*100))}%" if pd.notnull(x) else "N/A")
    md_lines.append(md_table.to_markdown(index=False))
    md_lines.append("\n## Regression: best_f1 ~ math_ratio\n")
    if "error" in regression_result:
        md_lines.append(f"Regression not available: {regression_result.get('error')}\n")
    else:
        md_lines.append(f"- **slope**: {regression_result['slope']:.6f}\n")
        md_lines.append(f"- **intercept**: {regression_result['intercept']:.6f}\n")
        md_lines.append(f"- **r_value**: {regression_result['r_value']:.6f}\n")
        md_lines.append(f"- **r_squared**: {regression_result['r_squared']:.6f}\n")
        md_lines.append(f"- **p_value**: {regression_result['p_value']:.6e}\n")
        md_lines.append(f"- **stderr**: {regression_result['stderr']:.6f}\n")
        md_lines.append(f"- **n**: {regression_result['n']}\n")
    md_lines.append("\n## Generated plots\n")
    md_lines.append("- `plots/mathratio_vs_bestf1.png`")
    md_lines.append("- `plots/mathratio_vs_mathacc.png`")
    md_lines.append("- `plots/mathratio_vs_codeacc.png`")
    md_lines.append("- `plots/val_f1_epochs.png`")
    md_lines.append("- `plots/math_acc_epochs.png`\n")
    md_lines.append("## Notes and warnings\n")
    if warnings_list:
        md_lines.append("Warnings encountered during processing:\n")
        for w in warnings_list:
            md_lines.append(f"- {w}\n")
    else:
        md_lines.append("No warnings.\n")

    with REPORT_MD.open("w", encoding="utf-8") as f:
        f.write("\n".join(md_lines))
except Exception as e:
    warnings_list.append(f"Failed to write markdown report: {e}")

# Final printout
print("\n=== Ablation aggregation complete ===")
print(f"Experiments processed: {len(rows)}")
print(f"Summary CSV: {SUMMARY_CSV}")
print(f"Summary JSON: {SUMMARY_JSON}")
print(f"Plots directory: {PLOTS_DIR}")
print(f"Regression JSON: {REGRESSION_JSON}")
print(f"Markdown report: {REPORT_MD}")
if warnings_list:
    print("\nWarnings:")
    for w in warnings_list:
        print(" -", w)
